# Stand-up Template

**Date:** {{date}}
**Attendees:** {{attendees}}

## Yesterday
- 

## Today
- 

## Blockers
- 

## Decisions
- [ ] Record ADR link(s):
