# All-Hands Template

**Week of:** {{week}}

## Metrics
- North Star:
- WAU/MAU:
- Defect rate:
- Cost per task:

## Updates by Workstream
- 

## Risks & Mitigations
- 

## Lessons Learned (append to registry)
- 
