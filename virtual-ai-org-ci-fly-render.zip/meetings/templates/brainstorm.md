# Brainstorm Template

**Topic:** {{topic}}
**Inputs:** competitor notes, user feedback, brief
**Facilitator:** {{owner}}

## Idea Map
- 

## Top-3 Concepts
1. 
2. 
3. 

## Decision Memo (if any)
- Problem statement:
- Option chosen:
- Why now:
